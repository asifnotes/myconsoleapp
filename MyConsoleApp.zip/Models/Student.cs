namespace MyConsoleApp.Models
{
    public class Student
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}