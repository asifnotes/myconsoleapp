using System.Collections.Generic;
using MyConsoleApp.Models;

namespace MyConsoleApp.Services
{
    public interface IStudentService
    {
        List<Student> GetAllStudents();
    }
}