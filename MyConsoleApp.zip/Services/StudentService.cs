using System.Collections.Generic;
using MyConsoleApp.Models;

namespace MyConsoleApp.Services
{
    public class StudentService : IStudentService
    {
        public List<Student> GetAllStudents()
        {
            return new List<Student>
            {
                new Student { Id = 1, Name = "Asif" },
                new Student { Id = 2, Name = "Moshiur" }
            };
        }
    }
}