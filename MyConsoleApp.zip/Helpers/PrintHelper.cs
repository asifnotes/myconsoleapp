using System;
using System.Collections.Generic;
using MyConsoleApp.Models;

namespace MyConsoleApp.Helpers
{
    public class PrintHelper
    {
        public static void PrintStudents(List<Student> students)
        {
            foreach (var student in students)
            {
                Console.WriteLine($"ID: {student.Id}, Name: {student.Name}");
            }
        }
    }
}